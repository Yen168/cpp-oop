﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
// data
using System.Data.SqlClient;
using System.Configuration;

public partial class regirster : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (IsPostBack)
        {
            SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["RegConnectionString"].ConnectionString);
            con.Open();
            string cmdstr = "Select count(*) form Register where BaruchID='" + TextBoxID + "'";
            SqlCommand userExist = new SqlCommand(cmdstr, con);
            // int temp = Convert.ToInt32(userExist.ExecuteScalar().ToString());

            // if (temp == 1)
            //  {
            //    Response.Write("User Already Exist!!!");
            // }

            //            else
            //          {
            //            Response.Write("Welcome to Exchange!!!");
            //      }
        }
    }
    protected void Submit_Click(object sender, EventArgs e)
    {

        SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["RegConnectionString"].ConnectionString);
        con.Open();
        string insCmd = "Insert into Registration (BaruchID, BaruchEMail, Password) values (@BaruchID, @BaruchEMail, @Password)";
        SqlCommand insertUser = new SqlCommand(insCmd, con);
        insertUser.Parameters.AddWithValue("@BaruchID", TextBoxID.Text);
        insertUser.Parameters.AddWithValue("@BBaruchEMail", TextBoxEM.Text);
        insertUser.Parameters.AddWithValue("@Password", TextBoxPW.Text);

        try
        {

           // insertUser.ExecuteNonQuery();
            con.Close();
            Response.Redirect("Login.aspx");
        }
       // catch (Exception er)
       // {

          //  Response.Write("Try Again!!!");


     //   }
        finally
        {

            //NOT YET

        }


    }
}