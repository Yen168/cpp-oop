﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.OleDb;

public partial class login : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void Button1_Click(object sender, EventArgs e)
    {

        if (TextBoxUID.Text != "" & TextBoxUPW.Text != "")
        {
            OleDbConnection objConnection = null;
            OleDbCommand objCmd = null;
            String strConnection, strSQL;

            strConnection = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=C:\\Documents and Settings\\Yen-an Chen\\My Documents\\Visual Studio 2010\\WebSites\\EXCHANGE\\Exchange.accdb;Jet OLEDB:Database Password=MyDbPassword;";

            objConnection = new OleDbConnection(strConnection);
            objConnection.ConnectionString = strConnection;

            objConnection.Open();

            // set the SQL string
            strSQL = "SELECT Count(*) FROM ExUser WHERE BaruchID = " + TextBoxUID.Text + " AND password = " + TextBoxUPW.Text;

            // Create the Command and set its properties
            objCmd = new OleDbCommand(strSQL, objConnection);

            // execute the command
            //int result = (int)objCmd.ExecuteNonQuery();
            OleDbDataReader ValueRead = objCmd.ExecuteReader();
           
            //objConnection.Close();


           // if (result > 0)
              //  Response.Redirect("result.aspx");
            //else
              //  Response.Redirect("regirster.aspx");
        }
    }
}